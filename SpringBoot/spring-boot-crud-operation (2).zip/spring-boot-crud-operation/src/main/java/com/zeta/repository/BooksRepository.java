package com.zeta.repository;
import org.springframework.data.repository.CrudRepository;

import com.zeta.model.Books;
public interface BooksRepository extends CrudRepository<Books, Integer>
{
}
